import os
from sqlalchemy import create_engine
from Limpieza import limpiar_y_estructurar_datos 

def cargar_datos_a_mysql(df_u, df_i, df_h, config):
    try:
        # 1. Conexión
        cadena_conexion = f"mysql+pymysql://{config['user']}:{config['pass']}@{config['host']}/{config['db']}"
        engine = create_engine(cadena_conexion)
        
        print("🔗 Conexión exitosa con MySQL.")

        # 2. Carga de Dimensiones
        print("Cargando dim_ubicacion...")
        df_u.to_sql('dim_ubicacion', con=engine, if_exists='append', index=False)
        
        print("Cargando dim_institucion...")
        df_i.to_sql('dim_institucion', con=engine, if_exists='append', index=False)

        # 3. Carga de Tabla de Hechos
        print("Cargando fact_matricula...")
        df_h.to_sql('fact_matricula', con=engine, if_exists='append', index=False)

        print("\n¡PROCESO ETL EXITOSO! Revisa tu MySQL Workbench.")

    except Exception as e:
        print(f"Error durante la carga: {e}")


mis_credenciales = {
    'user': 'root',           
    'pass': 'root',
    'host': 'localhost',
    'db': 'Practicum_Datos_6to'
}

if __name__ == "__main__":
    dir_actual = os.path.dirname(os.path.abspath(__file__))
    ruta_csv = os.path.join(dir_actual, "2_MINEDUC_RegistrosAdministrativos_2024-2025Inicio.csv")
    
    if os.path.exists(ruta_csv):
        print("Iniciando limpieza de datos...")
        ubicacion, institucion, hechos = limpiar_y_estructurar_datos(ruta_csv)
        
        cargar_datos_a_mysql(ubicacion, institucion, hechos, mis_credenciales)
    else:
        print(f"No se encontró el CSV en: {ruta_csv}")