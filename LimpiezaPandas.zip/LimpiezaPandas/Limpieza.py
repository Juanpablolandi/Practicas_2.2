import pandas as pd
import re
import os

def limpiar_y_estructurar_datos(ruta_csv):
    df = pd.read_csv(ruta_csv, sep=';', encoding='latin-1')
    
    def corregir_caracteres(texto):
        if isinstance(texto, str):
            correcciones = {
                'Ã\x81': 'A', 'Ã\x89': 'E', 'Ã\x8d': 'I', 'Ã\x93': 'O', 'Ã\x9a': 'U',
                'Ã\x91': 'N', 'Ã±': 'n', 'Ã³': 'o', 'Ã¡': 'a', 'Ã©': 'e', 
                'Ãí': 'i', 'Ãº': 'u', 'Ã‘': 'N', 'ã±': 'n', 'ã³': 'o'
            }
            for error, correccion in correcciones.items():
                texto = texto.replace(error, correccion)
            return texto
        return texto

    df = df.map(corregir_caracteres) if hasattr(df, 'map') else df.applymap(corregir_caracteres)

    # 2. LIMPIEZA DE COLUMNAS
    def normalizar_texto(texto):
        texto = texto.lower()
        # Reemplazos nombres de columnas
        texto = texto.replace('ã±', 'n').replace('ã³', 'o').replace('ã¡', 'a')
        texto = texto.replace('ã©', 'e').replace('ã\x81', 'a').replace('ã', 'a')
        # Eliminar cualquier cosa que no sea letra o número
        texto = re.sub(r'[^a-z0-9]', '', texto) 
        return texto

    df.columns = [normalizar_texto(col) for col in df.columns]
    
    print("Columnas normalizadas con éxito:", list(df.columns))

    # 3. Se nombró columnas
    col_estudiantes = 'totalestudiantes'
    col_docentes = 'totaldocentes'
    col_anio = 'anolectivo'
    col_regimen = 'regimenescolar'
    col_inst = 'nombreinstitucion'

    # Limpieza de columnas numéricas
    for col in [col_estudiantes, col_docentes]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype(int)
    
    # 1. Dimensión Ubicación
    dim_ubicacion = df[['provincia', 'canton', 'parroquia', 'area']].drop_duplicates().reset_index(drop=True)
    dim_ubicacion['id_ubicacion'] = dim_ubicacion.index + 1

    # 2. Dimensión Institución
    dim_institucion = df[['amie', col_inst, 'sostenimiento', col_regimen, 'modalidad']].drop_duplicates(subset=['amie'])
    dim_institucion = dim_institucion.rename(columns={
        col_inst: 'nombre_institucion',
        col_regimen: 'regimen_escolar'
    })

    # 3. Tabla de Hechos: Matrícula
    fact_temp = df.merge(dim_ubicacion, on=['provincia', 'canton', 'parroquia', 'area'])
    
    fact_matricula = fact_temp[['id_ubicacion', 'amie', col_anio, col_estudiantes, col_docentes]]
    
    fact_matricula = fact_matricula.rename(columns={
        col_anio: 'anio_lectivo',
        col_estudiantes: 'total_estudiantes',
        col_docentes: 'total_docentes'
    })

    return dim_ubicacion, dim_institucion, fact_matricula

if __name__ == "__main__":
    directorio_actual = os.path.dirname(os.path.abspath(__file__))
    nombre_archivo = "2_MINEDUC_RegistrosAdministrativos_2024-2025Inicio.csv"
    ruta_final = os.path.join(directorio_actual, nombre_archivo)
    
    if os.path.exists(ruta_final):
        print(f"Archivo encontrado en: {ruta_final}")
        ubicacion, institucion, hechos = limpiar_y_estructurar_datos(ruta_final)
        
        print("\nResumen de la Transformación (Semana 03):")
        print(f"- Registros en Dimensión Ubicación: {len(ubicacion)}")
        print(f"- Registros en Dimensión Institución: {len(institucion)}")
        print(f"- Registros en Tabla de Hechos (Matrícula): {len(hechos)}")
        
        # Guardar CSVs limpios
        ubicacion.to_csv(os.path.join(directorio_actual, "dim_ubicacion_limpia.csv"), index=False, encoding='utf-8-sig')
        institucion.to_csv(os.path.join(directorio_actual, "dim_institucion_limpia.csv"), index=False, encoding='utf-8-sig')
        hechos.to_csv(os.path.join(directorio_actual, "fact_matricula_limpia.csv"), index=False, encoding='utf-8-sig')
        
        print("\nArchivos .csv generados con codificación UTF-8.")
    else:
        print(f"ERROR: No se encontró el archivo '{nombre_archivo}'")