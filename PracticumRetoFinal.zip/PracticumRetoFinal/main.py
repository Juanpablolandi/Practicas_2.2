import os
import csv
import pg8000

# CONFIGURACIÓN DE CONEXIÓN A POSTGRESQL
USER = "postgres"
PASSWORD = "root"  
HOST = "localhost"
PORT = 5432  
DATABASE = "Practicum_2.2"

def get_table_metadata(cursor, table_name):
    """Obtiene el nombre de las columnas y sus tipos de datos reales en Postgres"""
    query = f"""
        SELECT column_name, data_type 
        FROM information_schema.columns 
        WHERE table_name = '{table_name}' AND table_schema = 'public';
    """
    cursor.execute(query)
    # Retorna un diccionario {nombre_columna: tipo_dato}
    return {row[0]: row[1] for row in cursor.fetchall()}

def load_csv_pg8000(conn, csv_path, table_name):
    if not os.path.exists(csv_path):
        print(f"⚠️ Archivo NO encontrado en ruta: {csv_path}")
        return
    
    print(f"⏳ Procesando: {os.path.basename(csv_path)} -> Tabla: '{table_name}'...")
    
    try:
        cursor = conn.cursor()
        
        # 1. Obtener metadatos de las columnas reales en Postgres
        metadata = get_table_metadata(cursor, table_name)
        if not metadata:
            print(f"❌ Error: La tabla '{table_name}' no existe en la base de datos.")
            cursor.close()
            return
            
        db_columns = list(metadata.keys())
        
        # 2. LIMPIEZA PREVIA (Evita el error 23505 de llaves duplicadas)
        cursor.execute(f'TRUNCATE TABLE "{table_name}" RESTART IDENTITY CASCADE;')
        
        with open(csv_path, mode='r', encoding='latin1', errors='ignore') as f:
            reader = csv.reader(f)
            csv_headers = [h.strip() for h in next(reader)]
            
            # Mapeos especiales sobre la marcha para corregir discrepancias menores de nombres
            mapped_headers = []
            for h in csv_headers:
                if h == "variacion_pib_percapita_pct" and "variacion_pib_pct" in db_columns:
                    mapped_headers.append("variacion_pib_pct")
                elif h == "pib_nominal_musd" and "pib_percapita_nominal" in db_columns:
                    mapped_headers.append("pib_percapita_nominal")
                else:
                    mapped_headers.append(h)
            
            # Filtrar columnas válidas
            valid_indices = []
            valid_cols_db = []
            for idx, h in enumerate(mapped_headers):
                if h in db_columns:
                    valid_indices.append(idx)
                    valid_cols_db.append(h)

            cols_str = ", ".join([f'"{c}"' for c in valid_cols_db])
            placeholders = ", ".join(["%s"] * len(valid_cols_db))
            query = f"INSERT INTO {table_name} ({cols_str}) VALUES ({placeholders});"
            
            # 3. Procesar y sanear filas de forma segura
            rows = []
            for row in reader:
                if not row:
                    continue
                
                filtered_row = [row[i] for i in valid_indices]
                processed_row = []
                
                for val, col_name in zip(filtered_row, valid_cols_db):
                    if val == "" or val is None:
                        processed_row.append(None)
                        continue
                    
                    col_type = metadata[col_name].lower()
                    
                    # Saneamiento para ENTEROS (Evita error de sintaxis bigint por '.0')
                    if "int" in col_type or "bigint" in col_type:
                        if "." in val:
                            val = val.split(".")[0] # '13682302.0' -> '13682302'
                    
                    # Saneamiento para TEXTO (Evita error 22001 recortando a un máximo de 50 caracteres)
                    elif "char" in col_type or "varchar" in col_type:
                        val = val[:50]
                        
                    processed_row.append(val)
                    
                rows.append(processed_row)
            
            # Inserción masiva limpia
            if rows:
                cursor.executemany(query, rows)
                conn.commit()
                print(f"✅ Éxito: Se inyectaron {len(rows)} filas en '{table_name}'.")
            else:
                print(f"⚠️ No se encontraron filas válidas para insertar en '{table_name}'.")
                
        cursor.close()
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Error en '{table_name}': {e}")

def run_pipeline():
    DATA_LIMPIA_DIR = r"D:\DOCUMETOS\Desktop\PracticumRetoFinal\data_limpia"
    
    mapping = {
        "silver_pib_real_anual.csv": "silver_pib_real_anual",
        "silver_pib_percapita_nominal.csv": "silver_pib_percapita_nominal",
        "silver_riesgo_pais.csv": "silver_riesgo_pais",
        "silver_iee_expectativas.csv": "silver_iee_expectativas",
        "silver_enemdu_laborales.csv": "silver_enemdu_laborales",
        "silver_supercias_directorio.csv": "silver_supercias_directorio",
        "silver_mineduc_bachilleres.csv": "silver_mineduc_bachilleres",
        "silver_vab_data.csv": "silver_vab_data",
        "silver_censo_actividad.csv": "silver_censo_actividad"
    }
    
    print("\n=======================================================")
    print("🚀 INICIANDO PIPELINE AUTO-ADAPTABLE ROBUSTO (CAPA SILVER)")
    print(f"📂 Buscando archivos CSV en: {DATA_LIMPIA_DIR}")
    print("=======================================================\n")
    
    if not os.path.exists(DATA_LIMPIA_DIR):
        print(f"❌ ERROR CRÍTICO: La carpeta '{DATA_LIMPIA_DIR}' no existe.")
        return
    
    try:
        conn = pg8000.connect(
            user=USER,
            password=PASSWORD,
            host=HOST,
            port=PORT,
            database=DATABASE
        )
    except Exception as e:
        print(f"❌ Error crítico al conectar a PostgreSQL: {e}")
        return

    for csv_file, table_name in mapping.items():
        csv_full_path = os.path.join(DATA_LIMPIA_DIR, csv_file)
        load_csv_pg8000(conn, csv_full_path, table_name)
        
    conn.close()
    print("\n=======================================================")
    print("🎉 PIPELINE CAPA SILVER COMPLETADO EXITOSAMENTE")
    print("=======================================================\n")

if __name__ == "__main__":
    run_pipeline()