import pandas as pd
import os

def clean_riesgo_pais(file_path, output_path):
    print(f"Iniciando limpieza de Riesgo País desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # Lectura nativa de CSV
    df = pd.read_csv(file_path, encoding='utf-8')
    df.columns = df.columns.str.strip()
    
    # CORRECCIÓN: Se cambió 'Período' por 'Periodo' (sin tilde) para que coincida con el CSV
    rename_dict = {
        'Periodo': 'fecha',
        'Anio': 'anio',
        'Mes': 'mes',
        'Dia': 'dia',
        'riesgo_pais_pb': 'riesgo_pais_pb'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # Ahora que sí se renombró correctamente, podemos convertir a datetime
    df['fecha'] = pd.to_datetime(df['fecha'], errors='coerce')
    
    # Forzar numérico entero para los puntos básicos (pb) de forma segura
    df['riesgo_pais_pb'] = pd.to_numeric(df['riesgo_pais_pb'], errors='coerce').astype('Int64')
    
    # Validar nulos en las columnas esenciales y eliminar duplicados por fecha única
    df.dropna(subset=['fecha', 'riesgo_pais_pb'], inplace=True)
    df.drop_duplicates(subset=['fecha'], keep='first', inplace=True)
    
    # Ordenar cronológicamente para mantener consistencia de serie de tiempo
    df.sort_values(by='fecha', ascending=True, inplace=True)
    
    # Guardar en la carpeta unificada data_limpia
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver de Riesgo País guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    # Cálculo dinámico de rutas absolutas basado en la ubicación de este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "riesgo_pais.csv"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_riesgo_pais.csv")
    
    # Crear automáticamente la carpeta data_limpia si no existe
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_riesgo_pais(INPUT, OUTPUT)