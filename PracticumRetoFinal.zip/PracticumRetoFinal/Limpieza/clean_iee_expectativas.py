import pandas as pd
import os

def clean_iee(file_path, output_path):
    print(f"Iniciando limpieza de Expectativas Empresariales (IEE) desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    df = pd.read_csv(file_path, encoding='utf-8')
    df.columns = df.columns.str.strip()
    
    rename_dict = {
        'Fecha': 'fecha',
        'IEE_global': 'iee_global',
        'Comercio': 'comercio',
        'Construccion': 'construccion',
        'Manufactura': 'manufactura'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # Convertir string 'AAAA-MM-DD' a date con pd.to_datetime()
    df['fecha'] = pd.to_datetime(df['fecha'], errors='coerce')
    
    # === AQUÍ SE CORRIGEN LOS NULLS: EXTRAER COMPONENTES DE TIEMPO ===
    df['anio'] = df['fecha'].dt.year
    df['mes'] = df['fecha'].dt.month
    
    # Limpieza de nulos y conversión de métricas a flotantes
    metricas = ['iee_global', 'comercio', 'construccion', 'manufactura']
    for col in metricas:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
    df.dropna(subset=['fecha'], inplace=True)
    
    # Asegurar que año y mes queden guardados como enteros limpios sin nulos
    df['anio'] = df['anio'].fillna(0).astype(int)
    df['mes'] = df['mes'].fillna(0).astype(int)
    
    df.drop_duplicates(subset=['fecha'], keep='first', inplace=True)
    
    # --- SOLUCIÓN AL ERROR DE COLUMNAS INTERNAS ---
    # Validamos dinámicamente qué columnas de la lista realmente existen en el DataFrame
    columnas_deseadas = ['fecha', 'anio', 'mes', 'iee_global', 'comercio', 'construccion', 'manufactura']
    columnas_finales = [col for col in columnas_deseadas if col in df.columns]
    
    df = df[columnas_finales]
    # -----------------------------------------------
    
    # Guardamos en formato 'latin1' de acuerdo a como lee tu main.py
    df.to_csv(output_path, index=False, encoding='latin1')
    print(f"Archivo Silver guardado con Año y Mes en: {output_path}")

if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "IEE_expectativas_empresariales.csv"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_iee_expectativas.csv")
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_iee(INPUT, OUTPUT)