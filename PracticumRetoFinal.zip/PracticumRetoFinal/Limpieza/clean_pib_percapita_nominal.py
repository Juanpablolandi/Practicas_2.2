import pandas as pd
import os

def clean_pib_nominal(file_path, output_path):
    print(f"Iniciando limpieza de PIB Per Cápita Nominal desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # Leer el archivo de Excel usando el motor openpyxl instalado
    df = pd.read_excel(file_path, engine='openpyxl')
    
    # Eliminar espacios fantasmas en los nombres de las columnas
    df.columns = df.columns.str.strip()
    
    # CORRECCIÓN: Se cambió 'Período' (con tilde) por 'Periodo' (sin tilde) para mapear el archivo real
    rename_dict = {
        'Periodo': 'periodo',
        'Anio': 'anio',
        'Poblacion': 'poblacion',
        'PIB_percapita_nominal_usd': 'pib_percapita_nominal'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # Eliminar filas completamente vacías
    df.dropna(how='all', inplace=True)
    
    # Asegurar el formato de fecha (Datetime) de forma nativa y segura
    df['periodo'] = pd.to_datetime(df['periodo'], errors='coerce')
    
    # Forzar tipos de datos correctos
    df['anio'] = pd.to_numeric(df['anio'], errors='coerce').astype('Int64')
    df['poblacion'] = pd.to_numeric(df['poblacion'], errors='coerce').astype('Int64')
    df['pib_percapita_nominal'] = pd.to_numeric(df['pib_percapita_nominal'], errors='coerce')
    
    # Control de nulos estructurales y duplicados por periodo único
    df.dropna(subset=['periodo', 'pib_percapita_nominal'], inplace=True)
    df.drop_duplicates(subset=['periodo'], keep='first', inplace=True)
    
    # Ordenar cronológicamente
    df.sort_values(by='periodo', ascending=True, inplace=True)
    
    # Guardar en la nueva carpeta unificada 'data_limpia'
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    # Cálculo dinámico de rutas absolutas basado en la ubicación de este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "pib_percapita_nominal.xlsx"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_pib_percapita_nominal.csv")
    
    # Crear la carpeta data_limpia de forma automática si no existe
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_pib_nominal(INPUT, OUTPUT)