import pandas as pd
import os

def clean_enemdu(file_path, output_path):
    print(f"Iniciando normalización y des-pivotaje (melt) de ENEMDU desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # 1. Cargar el CSV original de la carpeta DATA
    df = pd.read_csv(file_path, encoding='utf-8')
    
    # Eliminar espacios invisibles en las cabeceras
    df.columns = df.columns.str.strip()
    
    # 2. Aplicar melt usando las columnas REALES del archivo
    df_melted = pd.melt(
        df, 
        id_vars=['Encuesta', 'Periodo', 'Anio', 'Mes', 'Indicador'], 
        value_vars=['Nacional_Total', 'Area_Urbana', 'Area_Rural', 'Sexo_Hombre', 'Sexo_Mujer'],
        var_name='segmento_demografico', 
        value_name='valor_indicador'
    )
    
    # 3. Normalizar nombres de columnas resultantes a minúsculas para la base de datos
    df_melted.columns = df_melted.columns.str.lower()
    
    # 4. Limpieza defensiva de cadenas de texto
    df_melted['indicador'] = df_melted['indicador'].astype(str).str.strip()
    df_melted['periodo'] = df_melted['periodo'].astype(str).str.strip()
    df_melted['segmento_demografico'] = df_melted['segmento_demografico'].str.strip()
    
    # 5. Asegurar tipos de datos numéricos limpios
    df_melted['anio'] = pd.to_numeric(df_melted['anio'], errors='coerce').astype('Int64')
    df_melted['mes'] = pd.to_numeric(df_melted['mes'], errors='coerce').astype('Int64')
    df_melted['valor_indicador'] = pd.to_numeric(df_melted['valor_indicador'], errors='coerce').fillna(0)
    
    # 6. Evitar duplicados lógicos estructurales
    df_melted.drop_duplicates(subset=['periodo', 'indicador', 'segmento_demografico'], keep='first', inplace=True)
    
    # Guardar el resultado en la carpeta DATA
    df_melted.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver de ENEMDU guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "ENEMDU_indicadores_laborales.csv"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_enemdu_laborales.csv")
    
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_enemdu(INPUT, OUTPUT)