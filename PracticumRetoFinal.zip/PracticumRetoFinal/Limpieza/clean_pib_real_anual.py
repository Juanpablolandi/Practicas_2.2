import pandas as pd
import numpy as np
import os

def clean_pib_real(file_path, output_path):
    print(f"Iniciando limpieza de PIB Real Anual desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # Leer con el engine openpyxl listo
    df = pd.read_excel(file_path, engine='openpyxl')
    
    # Limpiar nombres de columnas eliminando espacios fantasmas
    df.columns = df.columns.str.strip()
    
    # Mapeo exacto según las columnas reales del archivo
    rename_dict = {
        'Anio': 'anio',
        'PIB_real_musd': 'pib_real_musd',
        'Poblacion': 'poblacion',
        'PIB_percapita_real_usd': 'pib_percapita',
        'Variacion_pib_musd_pct': 'variacion_pib_pct'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # CORRECCIÓN PARA PANDAS MODERNO: Se reemplaza .applymap() por .map()
    df = df.map(lambda x: x.strip() if isinstance(x, str) else x)
    
    # Forzar tipos de datos correctos de forma segura
    df['anio'] = pd.to_numeric(df['anio'], errors='coerce').astype('Int64')
    df['pib_real_musd'] = pd.to_numeric(df['pib_real_musd'], errors='coerce')
    df['poblacion'] = pd.to_numeric(df['poblacion'], errors='coerce').astype('Int64')
    df['pib_percapita'] = pd.to_numeric(df['pib_percapita'], errors='coerce')
    df['variacion_pib_pct'] = pd.to_numeric(df['variacion_pib_pct'], errors='coerce')
    
    # Control de nulos y duplicados estructurados
    df.dropna(subset=['anio'], inplace=True)
    df.drop_duplicates(subset=['anio'], keep='first', inplace=True)
    df['variacion_pib_pct'] = df['variacion_pib_pct'].fillna(0.0)
    
    df.sort_values(by='anio', ascending=True, inplace=True)
    
    # Exportar el resultado Silver en formato UTF-8
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    # Cálculo dinámico de rutas basado en la ubicación de este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "pib_real_anual.xlsx"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_pib_real_anual.csv")
    
    # Crear de forma automática la carpeta data_limpia si no existe
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_pib_real(INPUT, OUTPUT)