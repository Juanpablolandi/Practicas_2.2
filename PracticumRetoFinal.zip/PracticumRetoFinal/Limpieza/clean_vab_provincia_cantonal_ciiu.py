import pandas as pd
import re
import os

def clean_geo_text(text):
    if pd.isna(text):
        return ""
    text = str(text).strip()
    # Remover caracteres especiales manteniendo tildes, números, letras y guiones
    text = re.sub(re.compile(r'[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-]'), '', text)
    return " ".join(text.split()).upper()

def clean_vab_data(file_path, output_path):
    print(f"Iniciando limpieza de VAB desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # Leer el archivo de Excel usando el motor openpyxl
    df = pd.read_excel(file_path, engine='openpyxl')
    
    # Limpiar espacios en blanco invisibles en las cabeceras
    df.columns = df.columns.str.strip()
    
    # Mapeo de columnas de control geográfico y temporal a minúsculas
    rename_dict = {
        'ANIO': 'anio',
        'COD_PROVINCIA': 'cod_provincia',
        'PROVINCIA': 'provincia',
        'COD_CANTON': 'cod_canton',
        'CANTON': 'canton',
        'VAB_TOTAL_miles_usd': 'vab_total_miles_usd'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # CORRECCIÓN PARA PANDAS MODERNO: Cambiar .applymap() por .map() para limpiar strings celdas
    df = df.map(lambda x: x.strip() if isinstance(x, str) else x)
    
    # Normalización del texto geográfico de provincias y cantones
    df['provincia'] = df['provincia'].apply(clean_geo_text)
    df['canton'] = df['canton'].apply(clean_geo_text)
    
    # Forzar tipos de datos correctos para las claves e identificadores
    df['anio'] = pd.to_numeric(df['anio'], errors='coerce').astype('Int64')
    df['cod_provincia'] = pd.to_numeric(df['cod_provincia'], errors='coerce').astype('Int64')
    df['cod_canton'] = pd.to_numeric(df['cod_canton'], errors='coerce').astype('Int64')
    df['vab_total_miles_usd'] = pd.to_numeric(df['vab_total_miles_usd'], errors='coerce').fillna(0.0)
    
    # Identificar de forma dinámica todas las columnas de sectores CIIU (las numéricas del 1 al 14)
    columnas_ciiu = [col for col in df.columns if re.match(r'^\d+\s*-\s*', col)]
    
    # Asegurar que todas las columnas de industrias específicas sean numéricas flotantes
    for col in columnas_ciiu:
        df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0.0)
        
    # Eliminar duplicados estructurales por año y cantón único
    df.dropna(subset=['anio', 'cod_canton'], inplace=True)
    df.drop_duplicates(subset=['anio', 'cod_canton'], keep='first', inplace=True)
    
    # Guardar en la carpeta unificada data_limpia
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver de VAB guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    # Cálculo dinámico de rutas absolutas basado en la ubicación de este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "vab_provincia_cantonal_ciiu.xlsx"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_vab_data.csv")
    
    # Crear de forma automática la carpeta data_limpia si no existe
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_vab_data(INPUT, OUTPUT)