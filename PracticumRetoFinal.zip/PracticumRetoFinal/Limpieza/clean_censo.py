import pandas as pd
import os

def limpiar_censo():
    # Rutas de origen y destino
    # Ajusta 'D:/DOCUMETOS/Desktop/PracticumRetoFinal' si tu ruta base es distinta
    ruta_origen = r"D:\DOCUMETOS\Desktop\PracticumRetoFinal\DATA\censo2022_rama_actividad_provincia.csv"
    ruta_destino = r"D:\DOCUMETOS\Desktop\PracticumRetoFinal\data_limpia\silver_censo_actividad.csv"
    
    if not os.path.exists(ruta_origen):
        print(f"❌ No se encontró el archivo origen en: {ruta_origen}")
        return

    print("⏳ Iniciando la limpieza y transformación del Censo 2022...")
    
    # 1. Leer el CSV crudo
    df = pd.read_csv(ruta_origen, encoding='utf-8')
    
    # 2. Filtrar filas de totales generales del país si existieran para evitar ruido
    df = df[df['Provincia'].str.lower() != 'total']
    df = df[df['Rama_actividad'].str.lower().str.contains('total') == False]
    
    # 3. Aplicar melt() para despivotar 'Hombre' y 'Mujer' a una columna común 'sexo'
    df_melted = pd.melt(
        df,
        id_vars=['Provincia', 'Grupo_edad', 'Rama_actividad'],
        value_vars=['Hombre', 'Mujer'],
        var_name='sexo',
        value_name='personas_ocupadas'
    )
    
    # 4. Limpiar nombres de columnas a minúsculas para homologar con la BD
    df_melted.columns = [col.lower() for col in df_melted.columns]
    
    # 5. Asegurar limpieza de textos (quitar espacios en blanco fantasmas)
    df_melted['provincia'] = df_melted['provincia'].str.strip()
    df_melted['grupo_edad'] = df_melted['grupo_edad'].str.strip()
    df_melted['rama_actividad'] = df_melted['rama_actividad'].str.strip()
    
    # 6. Convertir métricas a valores numéricos enteros
    df_melted['personas_ocupadas'] = pd.to_numeric(df_melted['personas_ocupadas'], errors='coerce').fillna(0).astype(int)
    
    # Guardar en la carpeta data_limpia
    os.makedirs(os.path.dirname(ruta_destino), exist_ok=True)
    df_melted.to_csv(ruta_destino, index=False, encoding='latin1')
    print(f"✅ Censo transformado con éxito. Guardado en: {ruta_destino} ({len(df_melted)} filas).")

if __name__ == "__main__":
    limpiar_censo()