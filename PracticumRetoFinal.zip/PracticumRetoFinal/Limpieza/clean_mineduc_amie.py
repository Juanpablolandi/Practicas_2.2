import pandas as pd
import re
import os

def clean_geo_text(text):
    if pd.isna(text):
        return ""
    text = str(text).strip()
    text = re.sub(re.compile(r'[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-]'), '', text)
    return " ".join(text.split()).upper()

def clean_mineduc(file_path, output_path):
    print(f"Iniciando filtrado y limpieza de MINEDUC AMIE desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # Se lee con UTF-8. Si el archivo tuviera problemas de tildes heredados, puedes cambiarlo a 'latin-1'
    df = pd.read_csv(file_path, encoding='utf-8')
    df.columns = df.columns.str.strip()
    
    # CORRECCIÓN: Cambiado 'Ao_lectivo' por 'Ano_lectivo' para coincidir con el CSV real
    rename_dict = {
        'Ano_lectivo': 'anio_lectivo',
        'AMIE': 'codigo_amie',
        'Nombre_Institucion': 'nombre_institucion',
        'Zona': 'zona',
        'Provincia': 'provincia',
        'Cod_Provincia': 'cod_provincia',
        'Canton': 'canton',
        'Cod_Canton': 'cod_canton',
        'Nivel_Educacion': 'nivel_educacion',
        'Sostenimiento': 'sostenimiento',
        'Total_Estudiantes': 'total_estudiantes'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # REGLA DEL RETO: Filtrar estrictamente solo por Bachillerato
    df = df[df['nivel_educacion'].astype(str).str.contains('Bachillerato', case=False, na=False)]
    
    # Normalización geográfica y de texto institucional
    df['provincia'] = df['provincia'].apply(clean_geo_text)
    df['canton'] = df['canton'].apply(clean_geo_text)
    df['nombre_institucion'] = df['nombre_institucion'].astype(str).str.strip().str.upper()
    df['sostenimiento'] = df['sostenimiento'].astype(str).str.strip().str.upper()
    
    # Validar códigos geográficos enteros
    df['cod_provincia'] = pd.to_numeric(df['cod_provincia'], errors='coerce').astype('Int64')
    df['cod_canton'] = pd.to_numeric(df['cod_canton'], errors='coerce').astype('Int64')
    df['total_estudiantes'] = pd.to_numeric(df['total_estudiantes'], errors='coerce').fillna(0).astype(int)
    
    # Control de nulos y duplicados por periodo/institución utilizando la columna ya renombrada
    df.dropna(subset=['codigo_amie', 'provincia'], inplace=True)
    df.drop_duplicates(subset=['codigo_amie', 'anio_lectivo'], keep='first', inplace=True)
    
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver de Bachillerato guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    # Cálculo dinámico de rutas absolutas basado en la ubicación de este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "MINEDUC_AMIE_2023_2024.csv"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_mineduc_bachilleres.csv")
    
    # Crear automáticamente la carpeta data_limpia si no existe
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_mineduc(INPUT, OUTPUT)