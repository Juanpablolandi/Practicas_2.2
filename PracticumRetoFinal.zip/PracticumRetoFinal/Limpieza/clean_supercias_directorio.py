import pandas as pd
import re
import os

def clean_geo_text(text):
    if pd.isna(text):
        return ""
    text = str(text).strip()
    text = re.sub(re.compile(r'[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑ\s\-]'), '', text)
    return " ".join(text.split()).upper()

def clean_supercias(file_path, output_path):
    print(f"Iniciando limpieza de Supercias desde: {file_path}...")
    
    if not os.path.exists(file_path):
        print(f"Error: No se encontró el archivo en {file_path}")
        return

    # CORRECCIÓN 1: Forzamos que 'RUC' y 'Expediente' se lean como str para evitar DtypeWarning y conservar ceros a la izquierda
    df = pd.read_csv(file_path, encoding='utf-8', dtype={'RUC': str, 'Expediente': str})
    df.columns = df.columns.str.strip()
    
    # CORRECCIÓN 2: Eliminamos 'Canton' del mapeo ya que el archivo real no cuenta con dicha columna
    rename_dict = {
        'Expediente': 'expediente',
        'RUC': 'ruc',
        'Nombre': 'nombre_empresa',
        'Tipo_Compania': 'tipo_compania',
        'Cod_Provincia': 'cod_provincia',
        'Provincia': 'provincia'
    }
    df.rename(columns=rename_dict, inplace=True)
    
    # Normalización y limpieza de texto geográfico e institucional
    df['provincia'] = df['provincia'].apply(clean_geo_text)
    df['nombre_empresa'] = df['nombre_empresa'].astype(str).str.strip().str.upper()
    df['tipo_compania'] = df['tipo_compania'].astype(str).str.strip().str.upper()
    
    # Limpieza del RUC eliminando decimales fantasmas (.0) si existieran
    df['ruc'] = df['ruc'].apply(lambda x: str(x).split('.')[0].strip() if pd.notna(x) else "")
    df['cod_provincia'] = pd.to_numeric(df['cod_provincia'], errors='coerce').astype('Int64')
    
    # Control de nulos y eliminación de duplicados por clave primaria (RUC)
    df.dropna(subset=['ruc', 'provincia'], inplace=True)
    df = df[df['ruc'] != ""]
    df.drop_duplicates(subset=['ruc'], keep='first', inplace=True)
    
    # Guardar el archivo limpio en la carpeta data_limpia
    df.to_csv(output_path, index=False, encoding='utf-8')
    print(f"Archivo Silver de Supercias guardado exitosamente en: {output_path}")

if __name__ == "__main__":
    # Cálculo dinámico de rutas absolutas basado en la ubicación de este script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    INPUT = os.path.abspath(os.path.join(BASE_DIR, "..", "DATA", "Supercias_directorio_companias.csv"))
    OUTPUT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "data_limpia"))
    OUTPUT = os.path.join(OUTPUT_DIR, "silver_supercias_directorio.csv")
    
    # Crear automáticamente la carpeta data_limpia si no existe
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    clean_supercias(INPUT, OUTPUT)